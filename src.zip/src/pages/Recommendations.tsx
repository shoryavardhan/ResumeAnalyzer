
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Download, Share2, Star, Building, MapPin, DollarSign, Clock } from 'lucide-react';

const Recommendations = () => {
  const recommendedRoles = [
    {
      title: "Senior Product Manager",
      company: "TechFlow Inc.",
      location: "San Francisco, CA",
      salary: "$140k - $180k",
      match: 95,
      type: "Full-time",
      description: "Lead product strategy for B2B SaaS platform serving enterprise clients...",
      skills: ["Product Strategy", "User Research", "Analytics", "Roadmapping"]
    },
    {
      title: "Product Owner",
      company: "InnovateApp",
      location: "Remote",
      salary: "$110k - $140k",
      match: 88,
      type: "Remote",
      description: "Drive product development for mobile productivity applications...",
      skills: ["Agile", "User Stories", "Sprint Planning", "Stakeholder Management"]
    },
    {
      title: "Associate Product Manager",
      company: "StartupXYZ",
      location: "Austin, TX",
      salary: "$95k - $120k",
      match: 82,
      type: "Full-time",
      description: "Join early-stage fintech startup building payment solutions...",
      skills: ["Market Research", "Feature Specification", "A/B Testing", "SQL"]
    }
  ];

  const careerInsights = [
    {
      title: "Strengthen Technical Skills",
      description: "Consider learning SQL, basic analytics, and understanding technical architecture to better communicate with engineering teams.",
      priority: "High"
    },
    {
      title: "Build User Research Experience",
      description: "Gain hands-on experience with user interviews, usability testing, and customer feedback analysis.",
      priority: "Medium"
    },
    {
      title: "Develop Data Analysis Skills",
      description: "Learn to work with product analytics tools like Mixpanel, Amplitude, or Google Analytics.",
      priority: "Medium"
    }
  ];

  const recommendedCompanies = [
    { name: "Slack", type: "Enterprise Software", size: "Large", reason: "Strong product culture and collaboration focus" },
    { name: "Notion", type: "Productivity Tools", size: "Medium", reason: "Innovative approach to workspace products" },
    { name: "Linear", type: "Developer Tools", size: "Small", reason: "Product-focused team building tools for makers" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Navigation */}
      <nav className="border-b bg-white/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center text-xl font-bold text-slate-900">
              <ArrowLeft className="mr-2 h-5 w-5" />
              ResumeAnalyzer
            </Link>
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Export PDF
              </Button>
              <Button variant="outline" size="sm">
                <Share2 className="mr-2 h-4 w-4" />
                Share
              </Button>
              <Link to="/login">
                <Button variant="outline">Login</Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Star className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-slate-900 mb-4">Your Personalized Recommendations</h1>
          <p className="text-lg text-slate-600">Based on your resume analysis and product interests</p>
        </div>

        {/* Recommended Roles */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Recommended Product Roles</h2>
          <div className="space-y-6">
            {recommendedRoles.map((role, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <CardTitle className="text-xl">{role.title}</CardTitle>
                        <Badge variant="secondary" className="bg-green-100 text-green-800">
                          {role.match}% match
                        </Badge>
                      </div>
                      <div className="flex items-center text-slate-600 space-x-4 mb-3">
                        <div className="flex items-center">
                          <Building className="h-4 w-4 mr-1" />
                          {role.company}
                        </div>
                        <div className="flex items-center">
                          <MapPin className="h-4 w-4 mr-1" />
                          {role.location}
                        </div>
                        <div className="flex items-center">
                          <DollarSign className="h-4 w-4 mr-1" />
                          {role.salary}
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          {role.type}
                        </div>
                      </div>
                    </div>
                  </div>
                  <CardDescription className="text-base">{role.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <h4 className="font-semibold text-slate-900 mb-2">Key Skills:</h4>
                    <div className="flex flex-wrap gap-2">
                      {role.skills.map((skill, skillIndex) => (
                        <Badge key={skillIndex} variant="outline" className="text-blue-700 border-blue-200">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <Button className="bg-blue-600 hover:bg-blue-700">
                      View Details
                    </Button>
                    <Button variant="outline">
                      Save for Later
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Career Development Insights */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Career Development Insights</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {careerInsights.map((insight, index) => (
              <Card key={index} className="border-0 shadow-lg">
                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <CardTitle className="text-lg">{insight.title}</CardTitle>
                    <Badge variant={insight.priority === 'High' ? 'destructive' : 'secondary'}>
                      {insight.priority}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600">{insight.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Recommended Companies */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Companies to Consider</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {recommendedCompanies.map((company, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg">{company.name}</CardTitle>
                  <div className="flex gap-2">
                    <Badge variant="outline">{company.type}</Badge>
                    <Badge variant="secondary">{company.size}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600">{company.reason}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Next Steps */}
        <Card className="border-0 shadow-xl bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Ready for Your Next Move?</CardTitle>
            <CardDescription className="text-lg">
              Take action on these recommendations to advance your product career
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                Create Job Alerts
              </Button>
              <Button variant="outline">
                Schedule Career Consultation
              </Button>
              <Link to="/upload">
                <Button variant="outline">
                  Analyze Another Resume
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Recommendations;
