
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Check, CreditCard, Shield, Zap, Clock } from 'lucide-react';

const Payment = () => {
  const [processing, setProcessing] = useState(false);
  const navigate = useNavigate();

  const handlePayment = async () => {
    setProcessing(true);
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 3000));
    setProcessing(false);
    navigate('/recommendations');
  };

  const features = [
    "Complete resume analysis with detailed breakdown",
    "Personalized career recommendations",
    "Skill development roadmap",
    "Company and role suggestions",
    "Interview preparation tips",
    "Industry-specific insights",
    "30-day access to your results",
    "Email support for questions"
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Navigation */}
      <nav className="border-b bg-white/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center text-xl font-bold text-slate-900">
              <ArrowLeft className="mr-2 h-5 w-5" />
              ResumeAnalyzer
            </Link>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="text-green-600 border-green-200">
                Secure Checkout
              </Badge>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-4">Unlock Your Full Analysis</h1>
          <p className="text-lg text-slate-600">Get comprehensive insights and personalized career recommendations</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Features */}
          <Card className="border-0 shadow-xl">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="mr-2 h-5 w-5 text-yellow-500" />
                What's Included
              </CardTitle>
              <CardDescription>Everything you need to advance your career</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mt-0.5 mr-3 flex-shrink-0" />
                    <span className="text-slate-700">{feature}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Payment */}
          <Card className="border-0 shadow-xl">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <CreditCard className="h-8 w-8 text-white" />
              </div>
              <CardTitle>Complete Your Purchase</CardTitle>
              <CardDescription>One-time payment • Instant access</CardDescription>
            </CardHeader>
            <CardContent>
              {/* Pricing */}
              <div className="text-center mb-6">
                <div className="flex items-baseline justify-center mb-2">
                  <span className="text-4xl font-bold text-slate-900">$9</span>
                  <span className="text-2xl font-semibold text-slate-600">.99</span>
                </div>
                <p className="text-slate-600">One-time payment</p>
                <div className="mt-4 p-3 bg-green-50 rounded-lg border border-green-200">
                  <p className="text-sm font-semibold text-green-800">💡 Limited Time: 50% off regular price!</p>
                </div>
              </div>

              {/* Trust Indicators */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="text-center p-3 bg-slate-50 rounded-lg">
                  <Shield className="h-6 w-6 text-blue-600 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-slate-700">Secure Payment</p>
                  <p className="text-xs text-slate-500">256-bit SSL encrypted</p>
                </div>
                <div className="text-center p-3 bg-slate-50 rounded-lg">
                  <Clock className="h-6 w-6 text-green-600 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-slate-700">Instant Access</p>
                  <p className="text-xs text-slate-500">Results in seconds</p>
                </div>
              </div>

              {/* Mock Payment Form */}
              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    placeholder="your@email.com"
                    className="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Card Information
                  </label>
                  <input
                    type="text"
                    placeholder="1234 1234 1234 1234"
                    className="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 mb-2"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="MM / YY"
                      className="px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <input
                      type="text"
                      placeholder="CVC"
                      className="px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>

              <Button
                onClick={handlePayment}
                disabled={processing}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-lg py-3"
              >
                {processing ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    Processing...
                  </>
                ) : (
                  <>
                    <CreditCard className="mr-2 h-5 w-5" />
                    Complete Purchase - $9.99
                  </>
                )}
              </Button>

              <div className="text-center mt-4">
                <p className="text-xs text-slate-500">
                  By completing your purchase, you agree to our{' '}
                  <Link to="/terms" className="text-blue-600 hover:text-blue-700">Terms of Service</Link>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Money Back Guarantee */}
        <Card className="border-0 shadow-lg bg-green-50 border-green-200 mt-8">
          <CardContent className="text-center py-6">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="h-6 w-6 text-green-600" />
            </div>
            <h3 className="text-lg font-semibold text-green-800 mb-2">30-Day Money-Back Guarantee</h3>
            <p className="text-green-700">
              Not satisfied with your analysis? Get a full refund within 30 days, no questions asked.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Payment;
