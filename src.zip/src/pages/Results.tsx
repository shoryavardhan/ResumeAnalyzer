
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { ArrowLeft, ArrowRight, BarChart3, Target, Users, Building, Lock } from 'lucide-react';

const Results = () => {
  const [showPaywall, setShowPaywall] = useState(false);
  const navigate = useNavigate();

  // Mock analysis results
  const serviceScore = 35;
  const productScore = 65;

  const handleViewFullResults = () => {
    setShowPaywall(true);
  };

  const handleContinueToInterests = () => {
    navigate('/interests');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Navigation */}
      <nav className="border-b bg-white/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center text-xl font-bold text-slate-900">
              <ArrowLeft className="mr-2 h-5 w-5" />
              ResumeAnalyzer
            </Link>
            <div className="flex items-center space-x-4">
              <Link to="/login">
                <Button variant="outline">Login</Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-4">Your Resume Analysis</h1>
          <p className="text-lg text-slate-600">Here's what we discovered about your career orientation</p>
        </div>

        {/* Score Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="border-0 shadow-xl">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-blue-600" />
              </div>
              <CardTitle className="text-xl">Service-Oriented</CardTitle>
              <CardDescription>Focus on client services, consulting, support</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-4">{serviceScore}%</div>
              <Progress value={serviceScore} className="mb-4" />
              <p className="text-sm text-slate-600">
                Your experience shows moderate alignment with service-oriented roles
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-xl border-2 border-green-200">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Building className="h-8 w-8 text-green-600" />
              </div>
              <CardTitle className="text-xl">Product-Oriented</CardTitle>
              <CardDescription>Focus on product development, innovation, strategy</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <div className="text-4xl font-bold text-green-600 mb-4">{productScore}%</div>
              <Progress value={productScore} className="mb-4" />
              <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                <p className="text-sm font-semibold text-green-800">Primary Match</p>
              </div>
              <p className="text-sm text-slate-600">
                Your background strongly aligns with product-focused roles
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Key Insights - Preview */}
        <Card className="border-0 shadow-xl mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="mr-2 h-5 w-5" />
              Key Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                <h3 className="font-semibold text-green-800 mb-2">Strong Product Foundation</h3>
                <p className="text-green-700">
                  Your experience in technology roles and strategic thinking aligns well with product management and development positions.
                </p>
              </div>
              
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <h3 className="font-semibold text-blue-800 mb-2">Service Skills Present</h3>
                <p className="text-blue-700">
                  You also demonstrate client-facing abilities that could translate well to customer success or consulting roles.
                </p>
              </div>

              {/* Blurred content for paywall */}
              <div className="relative">
                <div className="filter blur-sm">
                  <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                    <h3 className="font-semibold text-purple-800 mb-2">Career Recommendations</h3>
                    <p className="text-purple-700">
                      Based on your profile, we recommend focusing on product roles in technology companies, particularly in areas like...
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 rounded-lg border border-orange-200 mt-4">
                    <h3 className="font-semibold text-orange-800 mb-2">Skill Development Areas</h3>
                    <p className="text-orange-700">
                      To strengthen your product orientation, consider developing skills in...
                    </p>
                  </div>
                </div>
                
                {/* Paywall overlay */}
                <div className="absolute inset-0 bg-white/90 rounded-lg flex items-center justify-center">
                  <div className="text-center p-6">
                    <Lock className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">Unlock Full Results</h3>
                    <p className="text-slate-600 mb-4">Get detailed recommendations and career guidance</p>
                    <Button onClick={handleViewFullResults} className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                      Unlock Now - $9.99
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            onClick={handleContinueToInterests}
            className="bg-blue-600 hover:bg-blue-700"
          >
            Continue to Product Interests
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
          <Button variant="outline" onClick={handleViewFullResults}>
            <Lock className="mr-2 h-4 w-4" />
            Unlock Full Analysis
          </Button>
          <Link to="/upload">
            <Button variant="outline" className="w-full sm:w-auto">
              Analyze Another Resume
            </Button>
          </Link>
        </div>
      </div>

      {/* Paywall Modal */}
      {showPaywall && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md border-0 shadow-2xl">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="h-8 w-8 text-white" />
              </div>
              <CardTitle>Unlock Your Full Analysis</CardTitle>
              <CardDescription>Get complete insights and personalized recommendations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 mb-6">
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                  <span className="text-slate-700">Detailed career recommendations</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                  <span className="text-slate-700">Skill development roadmap</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                  <span className="text-slate-700">Company and role suggestions</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                  <span className="text-slate-700">Interview preparation tips</span>
                </div>
              </div>
              
              <div className="text-center mb-6">
                <div className="text-3xl font-bold text-slate-900 mb-2">$9.99</div>
                <p className="text-slate-600">One-time payment • Instant access</p>
              </div>
              
              <div className="flex gap-3">
                <Button 
                  onClick={() => navigate('/payment')}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  Unlock Now
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setShowPaywall(false)}
                  className="flex-1"
                >
                  Maybe Later
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default Results;