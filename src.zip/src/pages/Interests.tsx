
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { ArrowLeft, ArrowRight, Target } from 'lucide-react';

const Interests = () => {
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [customDescription, setCustomDescription] = useState('');
  const navigate = useNavigate();

  const productAreas = [
    { id: 'mobile-apps', label: 'Mobile Applications', description: 'iOS, Android, cross-platform apps' },
    { id: 'web-platforms', label: 'Web Platforms', description: 'SaaS, web applications, online services' },
    { id: 'enterprise-software', label: 'Enterprise Software', description: 'B2B tools, workflow automation' },
    { id: 'consumer-products', label: 'Consumer Products', description: 'B2C applications, social platforms' },
    { id: 'fintech', label: 'Financial Technology', description: 'Banking, payments, investing apps' },
    { id: 'healthcare', label: 'Healthcare Technology', description: 'Medical devices, health apps, telemedicine' },
    { id: 'education', label: 'Educational Technology', description: 'Learning platforms, online courses' },
    { id: 'ai-ml', label: 'AI & Machine Learning', description: 'Intelligent systems, automation' },
    { id: 'iot', label: 'Internet of Things', description: 'Connected devices, smart home, wearables' },
    { id: 'gaming', label: 'Gaming & Entertainment', description: 'Video games, media, content platforms' },
    { id: 'ecommerce', label: 'E-commerce', description: 'Online retail, marketplaces, shopping' },
    { id: 'sustainability', label: 'Sustainability Tech', description: 'Green technology, environmental solutions' }
  ];

  const handleInterestToggle = (interestId: string) => {
    setSelectedInterests(prev => 
      prev.includes(interestId) 
        ? prev.filter(id => id !== interestId)
        : [...prev, interestId]
    );
  };

  const handleSubmit = () => {
    // Here you would typically save the data and process it
    navigate('/recommendations');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Navigation */}
      <nav className="border-b bg-white/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center text-xl font-bold text-slate-900">
              <ArrowLeft className="mr-2 h-5 w-5" />
              ResumeAnalyzer
            </Link>
            <div className="flex items-center space-x-4">
              <Link to="/login">
                <Button variant="outline">Login</Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Target className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-slate-900 mb-4">Product Interests</h1>
          <p className="text-lg text-slate-600">Tell us about the types of products you're passionate about working on</p>
        </div>

        <Card className="border-0 shadow-xl mb-8">
          <CardHeader>
            <CardTitle>What product areas interest you most?</CardTitle>
            <CardDescription>Select all that apply - this helps us provide more targeted recommendations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              {productAreas.map((area) => (
                <div 
                  key={area.id} 
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all hover:shadow-md ${
                    selectedInterests.includes(area.id) 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                  onClick={() => handleInterestToggle(area.id)}
                >
                  <div className="flex items-start space-x-3">
                    <Checkbox 
                      checked={selectedInterests.includes(area.id)}
                      onChange={() => handleInterestToggle(area.id)}
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-900 mb-1">{area.label}</h3>
                      <p className="text-sm text-slate-600">{area.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-xl mb-8">
          <CardHeader>
            <CardTitle>Describe your ideal product</CardTitle>
            <CardDescription>
              Tell us more about the specific type of product you'd love to work on (optional but helpful)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="For example: I'm passionate about building productivity tools that help remote teams collaborate better. I'm particularly interested in AI-powered features that can automate repetitive tasks and provide intelligent insights..."
              value={customDescription}
              onChange={(e) => setCustomDescription(e.target.value)}
              className="min-h-32 resize-none"
            />
            <p className="text-sm text-slate-500 mt-2">
              {customDescription.length}/500 characters
            </p>
          </CardContent>
        </Card>

        {/* Progress indicator */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <div className="w-8 h-1 bg-green-500 rounded"></div>
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <div className="w-8 h-1 bg-green-500 rounded"></div>
            <div className="w-3 h-3 bg-blue-500 rounded-full border-2 border-blue-600"></div>
            <div className="w-8 h-1 bg-slate-300 rounded"></div>
            <div className="w-3 h-3 bg-slate-300 rounded-full"></div>
          </div>
          <p className="text-sm text-slate-600">Step 3 of 4</p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/results">
            <Button variant="outline" className="w-full sm:w-auto">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Results
            </Button>
          </Link>
          <Button 
            onClick={handleSubmit}
            disabled={selectedInterests.length === 0}
            className="bg-blue-600 hover:bg-blue-700"
          >
            Generate Recommendations
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>

        {selectedInterests.length === 0 && (
          <p className="text-center text-slate-500 text-sm mt-4">
            Please select at least one area of interest to continue
          </p>
        )}
      </div>
    </div>
  );
};

export default Interests;